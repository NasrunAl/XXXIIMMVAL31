<div class="card p-4">
  <h4>Kuesioner Perbandingan Kriteria</h4>
  <p>Isi nilai perbandingan antar kriteria.</p>
  <!-- form kriteria -->
  <form action="alternatives.php" method="POST">
    <!-- generate matrix here -->
    <button type="submit" class="btn btn-primary">Lanjut ke Alternatif →</button>
  </form>
</div>
