<div class="card p-4">
  <h4>Kuesioner Perbandingan Alternatif</h4>
  <form action="result.php" method="POST">
    <!-- matrix input alternatif -->
    <button type="submit" class="btn btn-primary">Lanjut ke Hasil →</button>
  </form>
</div>
