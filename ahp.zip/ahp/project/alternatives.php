<?php
$title = "Kuesioner Alternatif";
$page = "pages/alternatives_content.php";
include "layout.php";
