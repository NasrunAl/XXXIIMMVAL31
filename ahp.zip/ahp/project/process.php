<?php
$title = "Proses Data (Hasil AHP)";
$page = "pages/process_content.php";
include "layout.php";