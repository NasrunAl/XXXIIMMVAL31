<?php
$title = "Riwayat Perhitungan";
$page = "pages/history_content.php";
include "layout.php";