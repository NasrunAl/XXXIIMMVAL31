<?php
$title = "Kuesioner Kriteria";
$page = "pages/criteria_content.php";
include "layout.php";
