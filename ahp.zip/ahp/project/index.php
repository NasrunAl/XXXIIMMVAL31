<?php
// index.php (root) - wrapper: set page and include layout
$title = "AHP - Pemilihan Mahasiswa Terbaik";
$page = "pages/index_content.php";
include "layout.php";
