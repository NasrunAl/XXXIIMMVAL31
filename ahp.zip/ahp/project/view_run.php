<?php 
$title = "Detail Run";
$page = "pages/view_run_content.php";
include "layout.php";