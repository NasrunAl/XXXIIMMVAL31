<?php
$title = "Setup AHP";
$page = "pages/setup_content.php";
include "layout.php";
