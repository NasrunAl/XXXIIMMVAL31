<?php
$title = "Hasil Perhitungan AHP";
$page = "pages/result_content.php";
include "layout.php";
